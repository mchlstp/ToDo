let myButton = document.querySelector("#addToDo");
let myList = document.querySelector("#toDoContainer");
let myInput = document.querySelector("#inputField");
myButton.addEventListener("click", function() {
    // create a new li element held "item" variable let item = document.createElement("li"); //
let item = document.createElement("li");
item.innerText = myInput.value;
myList.appendChild(item);
myInput.value = "";

item.addEventListener("click", function(){
   myList.removeChild(item);
});
});

